#include <thread>
#include <vector>
#include <memory>
#include <mutex>
#include <atomic>
#include "KeyFinder.h"
#include "CudaKeySearchDevice.h"
#include "DeviceManager.h"
#include "Logger.h"
#include "util.h"
#include "AddressUtil.h"

std::vector<std::string> targets;

void runInstance(int deviceId, secp256k1::uint256 startKey, secp256k1::uint256 endKey, secp256k1::uint256 stride,
                 int compression, int threads, int blocks, int pointsPerThread) {
    try {
        Logger::log(LogLevel::Info, "[GPU " + std::to_string(deviceId) + "] Iniciando dispositivo...");

        std::unique_ptr<CudaKeySearchDevice> device(new CudaKeySearchDevice(deviceId, threads, pointsPerThread, blocks));

        KeyFinder finder(startKey, endKey, compression, device.get(), stride);

        finder.setResultCallback([](KeySearchResult info) {
            std::string s = info.address + " " + info.privateKey.toString(16) + " " + info.publicKey.toString(info.compressed);
            Logger::log(LogLevel::Info, "[MATCH] " + s);
            util::appendToFile("matches.txt", s);
        });

        finder.setStatusCallback([](KeySearchStatus info) {
            Logger::log(LogLevel::Info, "[Status GPU] " + info.deviceName + ": " + util::format("%.2f", info.speed) + " MKey/s");
        });

        finder.setStatusInterval(5000);
        finder.init();

        finder.setTargets(targets);
        finder.run();

    } catch (KeySearchException &ex) {
        Logger::log(LogLevel::Error, "Erro na GPU " + std::to_string(deviceId) + ": " + ex.msg);
    }
}

int main(int argc, char **argv) {
    Logger::log(LogLevel::Info, "Detectando GPUs...");
    auto devices = DeviceManager::getDevices();

    if (devices.empty()) {
        Logger::log(LogLevel::Error, "Nenhuma GPU CUDA encontrada.");
        return 1;
    }

    int blocks = 32;
    int threads = 256;
    int pointsPerThread = 32;
    int compression = PointCompressionType::COMPRESSED;
    secp256k1::uint256 startKey("1");
    secp256k1::uint256 stride("1");
    secp256k1::uint256 endKey = secp256k1::N - 1;

    // ✅ Correção aqui: usa readLinesFromStream
    util::readLinesFromStream("targets.txt", targets);
    if (targets.empty()) {
        Logger::log(LogLevel::Error, "Arquivo targets.txt está vazio ou não encontrado.");
        return 1;
    }

    Logger::log(LogLevel::Info, util::format("%d targets carregados.", (int)targets.size()));

    std::vector<std::thread> gpuThreads;
    for (int i = 0; i < devices.size(); ++i) {
        secp256k1::uint256 totalRange = endKey - startKey + 1;
        secp256k1::uint256 rangePerGPU = totalRange.div(devices.size());

        // ✅ Correção aqui: cast explícito de i para uint256
        secp256k1::uint256 gpuStart = startKey + (rangePerGPU * secp256k1::uint256(i));
        secp256k1::uint256 gpuEnd = (i == devices.size() - 1) ? endKey : (gpuStart + rangePerGPU - 1);

        gpuThreads.emplace_back(runInstance, i, gpuStart, gpuEnd, stride, compression, threads, blocks, pointsPerThread);
    }

    for (auto &t : gpuThreads) {
        t.join();
    }

    Logger::log(LogLevel::Info, "Finalizado em todas as GPUs.");
    return 0;
}
